# Trustworthy Prediction and Root-Cause Identification for Telecom Networks

Submission package for review. Start with the paper; open the notebooks only if you want to see
the executed code and full outputs behind each result.

## Contents

1. **`Trustworthy_RCA_Framework_Paper.docx`** — the write-up. Framework design, method, results,
   limitations, discussion. Start here.
2. **`notebooks_html/`** — six executed notebooks, exported to HTML (open directly in a browser,
   no Jupyter needed). Each shows the actual code, printed output, tables, and figures behind the
   paper's numbers.
   - `Telecom_Trustworthy_AI_Framework.html` — the main notebook: framework design (§0-4),
     end-to-end demo of all five components (§5-13).
   - `01_smd_data_audit.html` — dataset loading, label parsing checks, leakage audit (PASS/FAIL).
   - `02_prediction_baselines.html` — naive/classical/statistical/strong baselines vs. the
     proposed models, across 5 random seeds, with significance testing.
   - `04_root_cause_localization.html` — fixed-k root-cause metrics vs. random and
     correlation-only baselines.
   - `05_dependency_causal_analysis.html` — Granger-causality filtering across all events, with
     multiple-comparison correction.
   - `08_explanation_faithfulness.html` — explanation stability/faithfulness tests, and the
     central trustworthy-AI question: does the model's own confidence predict when it is wrong.
3. **`research_paper_feasibility_analysis.md`** — a self-critical assessment of what in this work
   is genuinely novel vs. engineering, what a full research paper would still need, and honest
   scores against Q1-journal expectations. Optional background reading.

## Headline results

- Early-warning prediction: best model reaches 0.88 AUPRC on held-out data, but a simple
  unsupervised reconstruction baseline gets within one standard deviation of it, and the advantage
  over the classical baseline is not statistically significant at the tested sample size (n=5
  seeds) — reported as a limitation, not hidden.
- Root-cause localization: attribution-based ranking beats chance by a wide margin, but is
  *outperformed* by a much simpler correlation-based baseline on this dataset — an unexpected,
  verified (not a bug) finding worth discussing.
- The central trustworthy-AI test: does the model's own confidence predict whether its root-cause
  diagnosis is correct? On this evidence, **no** — confidence, explanation stability, and
  explanation faithfulness are statistically indistinguishable between correct and incorrect
  diagnoses. This is the most important finding in the project.

## Reproducibility

All code, data-loading, and results are public/open: dataset fetched live from the NetManAIOps
GitHub repository (no license or access restrictions), all libraries are standard open-source
(scikit-learn, LightGBM, PyTorch, SHAP, statsmodels). Every notebook runs top-to-bottom
independently.
